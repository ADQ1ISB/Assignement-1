let personName:string ="Ali";
console.log(`Hello ${personName},would you like to learn some Python today?`);