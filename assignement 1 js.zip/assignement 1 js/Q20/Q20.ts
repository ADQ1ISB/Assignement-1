// create an array of programming languages
let languages: string[] = ['JavaScript', 'Python', 'Java', 'TypeScript', 'Ruby'];

// print the list of programming languages
console.log("List of programming languages:");
for (let i=0; i<languages.length; i++) {
    console.log (`- ${languages[i]}`);
}