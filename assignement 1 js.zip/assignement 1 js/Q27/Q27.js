var aliencolor = "Green";
if (aliencolor == "Green") {
    console.log("Player earned 5 points");
}
else {
    console.log("Player earned 0 points");
}
var aliencolor = "Yellow";
if (aliencolor == "Yellow") {
    console.log("Player earned 10 points");
}
else {
    console.log("Player earned 0 points");
}
var aliencolor = "Red";
if (aliencolor == "Red") {
    console.log("Player earned 15 points");
}
else {
    console.log("Player earned 0 points");
}
