let aliencolor : string = "Green";
if (aliencolor == "Green"){
    console.log("Player earned 5 points");
}else{
    console.log("Player earned 0 points")
}
let aliencolor : string = "Yellow";
if (aliencolor == "Yellow"){
    console.log("Player earned 10 points");
}else{
    console.log("Player earned 0 points")
}
let aliencolor : string = "Red";
if (aliencolor == "Red"){
    console.log("Player earned 15 points");
}else{
    console.log("Player earned 0 points")
}