const names: string[] = ["Alice", "Bob", "Charlie", "David"];
for (let i=0; i<names.length;i++) {
  console.log(names[i]);
}