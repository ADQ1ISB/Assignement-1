var names = ["Alice", "Bob", "Charlie", "David"];
for (var i = 0; i < names.length; i++) {
    console.log(names[i]);
}
