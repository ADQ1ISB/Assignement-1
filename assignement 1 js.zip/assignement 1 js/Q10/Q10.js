// Program 1: Favorite Number
// This program stores a favorite number in a variable and prints a message revealing the number.
var favoriteNumber = 7;
console.log("My favorite number is " + favoriteNumber);
// Program 2: Simple Calculator
// This program shows two numbers and then performs basic math operations on them.
// Prompt the user for two numbers
var num1 = 10;
var num2 = 4;
// Perform basic math operations
var sum = num1 + num2;
var difference = num1 - num2;
var product = num1 * num2;
var quotient = num1 / num2;
// Display the results
console.log("Sum: ".concat(sum));
console.log("Difference: ".concat(difference));
console.log("Product: ".concat(product));
console.log("Quotient: ".concat(quotient));
