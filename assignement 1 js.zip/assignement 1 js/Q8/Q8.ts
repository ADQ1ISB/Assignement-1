console.log(6 + 2);
console.log(10 - 2);
console.log(2 * 4);
console.log(16 / 2);