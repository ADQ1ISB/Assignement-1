const guests: string[] = ['Albert Einstein', 'Marie Curie', 'Nikola Tesla'];

for (let i = 0; i < guests.length; i++) {
  console.log(`Dear ${guests[i]},\nI would like to invite you to a dinner at my place on Saturday. It would be an honor to have you as my guest. Please let me know if you can make it.\nBest regards,\n[Your Name]`);
}
