var favoriteNumber = 7;
var message = ("My favorite number is " + favoriteNumber + ".");
console.log(message);
