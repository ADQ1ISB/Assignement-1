let favoriteNumber: number = 7;
let message: string = ("My favorite number is " + favoriteNumber + ".");
console.log(message);