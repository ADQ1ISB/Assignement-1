let names : string = ["Alice", "Bob", "Charlie" ,"David"];

for (let i = 0; i < names.length; i++) {
 console.log(`Hello, ${names[i]}! How are you doing today?`);
}