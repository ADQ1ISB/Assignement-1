let alien_color = 'green';

if (alien_color === 'green') {
  console.log("The player just earned 5 points for shooting the alien.");
} else {
  console.log("The player just earned 10 points.");
}
let alien_color = 'yellow';

if (alien_color === 'green') {
  console.log("The player just earned 5 points for shooting the alien.");
} else {
  console.log("The player just earned 10 points.");
}