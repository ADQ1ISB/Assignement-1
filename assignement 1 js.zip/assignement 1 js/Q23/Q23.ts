let a = 5;
let b = 10;

// Test 1
console.log("Is a less than b? I predict True.");
console.log(a < b);

// Test 2
console.log("Is a greater than b? I predict False.");
console.log(a > b);

// Test 3
console.log("Is a equal to b? I predict False.");
console.log(a == b);

// Test 4
console.log("Is a not equal to b? I predict True.");
console.log(a != b);

let str1 = "hello";
let str2 = "HELLO";

// Test 5
console.log("Is str1 equal to 'hello'? I predict True.");
console.log(str1 == "hello");

// Test 6
console.log("Is str1 equal to str2? I predict False.");
console.log(str1 == str2);

// Test 7
console.log("Is str1 not equal to str2? I predict True.");
console.log(str1 != str2);

let x = true;
let y = false;

// Test 8
console.log("Is x equal to y? I predict False.");
console.log(x == y);

// Test 9
console.log("Is x not equal to y? I predict True.");
console.log(x != y);

let num = 7;

// Test 10
console.log("Is num greater than 5 and less than 10? I predict True.");
console.log(num > 7 && num < 10);