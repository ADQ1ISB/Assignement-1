let alien_color: string = 'green';

if (alien_color === 'green') {
  console.log("You just earned 5 points!");
}
let alien_color: string = 'red';

if (alien_color === 'green') {
  console.log("You just earned 5 points!");
}