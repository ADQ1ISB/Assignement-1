var alien_color = 'green';
if (alien_color === 'green') {
    console.log("You just earned 5 points!");
}
var alien_color = 'red';
if (alien_color === 'green') {
    console.log("You just earned 5 points!");
}
