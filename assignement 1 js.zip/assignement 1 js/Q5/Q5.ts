let famous_person: string = "Albert Einstein";
let quote: string = "A person who never made a mistake never tried anything new.";
let message: string = `${famous_person} once said, "${quote}"`;
console.log(message);