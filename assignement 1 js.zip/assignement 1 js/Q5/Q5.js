var famous_person = "Albert Einstein";
var quote = "A person who never made a mistake never tried anything new.";
var message = "".concat(famous_person, " once said, \"").concat(quote, "\"");
console.log(message);
