var Pizzas = ["Jalapeno", "Veggie Pizza", "Pepperoni"];
for (var i = 0; i < Pizzas.length; i++) {
    console.log(Pizzas[i]);
}
for (var j = 0; j < Pizzas.length; j++) {
    console.log("I like ".concat(Pizzas[j], " Pizza"));
}
console.log("I love pizza with lots of cheese and pepperoni. Its my go-to pizza and always hits the spot.Another favorite of mine is veggie pizza with lots of fresh vegetables like bell peppers, mushrooms, and onions. Its a healthier option that still tastes delicious.And when I am feeling adventurous, I like to try latest and unique pizza toppings like barbecue chicken or pineapple and ham. Its fun to mix it up and discover latest flavor comIbinations.I really love Pizza");
