let personage : number = 1;
if (personage < 2){
    console.log("Person is a baby");
}else{
    console.log("Person is not a baby")
}

let personage : number = 2;
if (personage >= 2 && personage < 4 ){
    console.log("Person is a toddler");
}else{
    console.log("Person is not a toddler")
}

let personage : number = 5;
if (personage >= 4 && personage < 13 ){
    console.log("Person is a kid");
}else{
    console.log("Person is not a kid")
}

let personage : number = 17;
if (personage >= 17 && personage < 20){
    console.log("Person is a teenager");
}else{
    console.log("Person is not a teenager")
}

let personage : number = 45;
if (personage >= 20 && personage < 65){
    console.log("Person is an adult");
}else{
    console.log("Person is not an adult")
}

let personage : number = 69;
if (personage >= 65){
    console.log("Person is an elder");
}else{
    console.log("Person is not an elder")
}
