var personage = 1;
if (personage < 2) {
    console.log("Person is a baby");
}
else {
    console.log("Person is not a baby");
}
var personage = 2;
if (personage >= 2 && personage < 4) {
    console.log("Person is a toddler");
}
else {
    console.log("Person is not a toddler");
}
var personage = 5;
if (personage >= 4 && personage < 13) {
    console.log("Person is a kid");
}
else {
    console.log("Person is not a kid");
}
var personage = 17;
if (personage >= 17 && personage < 20) {
    console.log("Person is a teenager");
}
else {
    console.log("Person is not a teenager");
}
var personage = 45;
if (personage >= 20 && personage < 65) {
    console.log("Person is an adult");
}
else {
    console.log("Person is not an adult");
}
var personage = 69;
if (personage >= 65) {
    console.log("Person is an elder");
}
else {
    console.log("Person is not an elder");
}
