let name: string = "\t\n Eric John \t\n"
console.log("Name with whitespace" + name);
console.log("Name after stripping whitespace" + name.trim());