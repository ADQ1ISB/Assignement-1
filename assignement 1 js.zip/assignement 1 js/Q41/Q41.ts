let magicians : string[]=["David Copperfield","Penn & Teller","Criss Angel","Harry Houdini","Shin Lim"];

function show_magicians (magicians : string[]):void {
    for (let i=0; i<magicians.length;i++){
        console.log(magicians[i]);
    }
}
show_magicians(magicians);