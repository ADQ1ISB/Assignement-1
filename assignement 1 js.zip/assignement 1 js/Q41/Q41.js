var magicians = ["David Copperfield", "Penn & Teller", "Criss Angel", "Harry Houdini", "Shin Lim"];
function show_magicians(magicians) {
    for (var i = 0; i < magicians.length; i++) {
        console.log(magicians[i]);
    }
}
show_magicians(magicians);
