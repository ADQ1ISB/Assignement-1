// create a person object with properties like name, age, and occupation
var person = {
    name: "John",
    age: 30,
    occupation: "Developer"
};
// print the person object
console.log(person);
