var vehicles = ['car', 'motorcycle', 'bicycle', 'scooter'];
for (var i = 0; i < vehicles.length; i++) {
    console.log("I would like to own a ".concat(vehicles[i], "."));
}
