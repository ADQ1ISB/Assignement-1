let vehicles: string []= ['car', 'motorcycle', 'bicycle', 'scooter'];
for (let i=0;i<vehicles.length;i++){
  console.log(`I would like to own a ${vehicles[i]}.`);
}