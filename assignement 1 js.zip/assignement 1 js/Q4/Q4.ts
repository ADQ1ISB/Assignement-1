const author: string = "Steve Jobs";
const quote: string = "Innovation distinguishes between a leader and a follower.";
console.log(`${author} once said, "${quote}"`);