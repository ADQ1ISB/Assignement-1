var author = "Steve Jobs";
var quote = "Innovation distinguishes between a leader and a follower.";
console.log("".concat(author, " once said, \"").concat(quote, "\""));
