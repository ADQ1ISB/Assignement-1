console.log("addition", 5 + 3); // addition: 8
console.log("subtraction", 15 - 7); // subtraction: 8
console.log("multiplication", 2 * 4); // multiplication: 8
console.log("division", 24 / 3); // division: 8
