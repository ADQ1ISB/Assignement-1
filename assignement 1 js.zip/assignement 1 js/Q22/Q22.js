var array = [1, 2, 3];
console.log(array[3]); // accessing an index that does not exist in the array will produce an error
console.log(array[2]); // correct index value
