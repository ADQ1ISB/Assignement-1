// starting with Q14
var guestlist = ["Alex", "Robert", "Simon"];
console.log("I am inviting ".concat(guestlist.length, " guests to dinner"));
