// starting with Q14
let guestlist : string []= ["Alex","Robert","Simon"];
console.log(`I am inviting ${guestlist.length} guests to dinner`);