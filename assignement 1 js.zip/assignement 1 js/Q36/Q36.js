// Calling function
make_shirt("Medium", "GoodLuck");
function make_shirt(size, message) {
    console.log("The shirt is a ".concat(size, " and it has the ").concat(message, " printed on it"));
}
