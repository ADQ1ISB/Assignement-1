// Calling function
make_shirt("Medium" , "GoodLuck");
// funs=ction definition
function make_shirt(size:string, message:string){
    console.log(`The shirt is a ${size} size and it has ${message} printed on it`);
}