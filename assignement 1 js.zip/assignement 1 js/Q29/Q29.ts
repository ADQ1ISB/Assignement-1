let favorite_fruit : string [] = ["Apple", "Banana", "Peach"];
if (favorite_fruit.includes("Apple") ){
    console.log("I really like Apples");
}
if (favorite_fruit.includes("Banana") ){
    console.log("I really like Bananas");
}
if (favorite_fruit.includes("Peach") ){
    console.log("I really like Peaches");
}